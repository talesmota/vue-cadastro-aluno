export default class Aluno{
    constructor(name='', email='', cell='', course='', state='', city=''){
        this.name=name;
        this.email=email;
        this.cell=cell;
        this.course=course;
        this.state=state;
        this.city=city;
    }
};