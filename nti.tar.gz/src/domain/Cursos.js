export const CURSOS = [
    {id:1, name:"Arquitetura e Urbanismo"},
    {id:2, name:"Administração"},
    {id:3, name:"Artes Cênicas"},
    {id:4, name:"Ciência da Computação"},
    {id:5, name:"Ciência e Tecnologia de Alimentos"},
    {id:6, name:"Ciências Biológicas"},
    {id:7, name:"Ciências Econômicas"},
    {id:8, name:"Direito"},
    {id:9, name:"Educação Física"},
    {id:10, name:"Engenharia Ambiental"}
];

        