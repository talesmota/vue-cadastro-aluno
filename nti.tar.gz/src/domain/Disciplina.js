export default class Disciplina{
    constructor(name='',code='',students=[]){
        this.name=name;
        this.code=code;
        this.students=students;
    }
}