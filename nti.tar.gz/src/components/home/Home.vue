<template>
  <div>
      <h1>HOME</h1>
  </div>
</template>
<script>
export default {
  created(){
    console.log("HOME")
  }
}
</script>
<style>

</style>

