<template>
  <div>
        <h1 v-if="!this.id">Cadastrar Disciplina</h1>
        <h1 v-else>Editar Disciplina</h1>
        <form @submit.prevent="grava()">
            <div class="form-group">
                <label for="name">Nome:</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Digite seu nome" 
                    v-model="disciplina.name" v-validate data-vv-rules="required|min:3|max:30" data-vv-as="Nome"  />
                <div class="alert alert-danger" role="alert" v-show="errors.has('name')">{{ errors.first('name') }}</div>
            </div>
            <div class="form-group">
                <label for="code">Código:</label>
                <input type="text" class="form-control" id="code" name="code" placeholder="Digite o código da disciplina"
                    v-model="disciplina.code" v-validate data-vv-rules="required|min:3" data-vv-as="Disciplina" />
                <div class="alert alert-danger" role="alert" v-show="errors.has('code')">{{ errors.first('code') }}</div>
            </div>
            
            
            <div class="botao">
                <button class="btn btn-default" >Voltar</button>
                <button class="btn btn-primary" >Cadsatrar</button>
            </div>
        </form>
    </div>
</template>

<script>

import Disciplina from "../../domain/Disciplina.js";
import DisciplinaService from "../../services/disciplina/DisciplinaService.js";
export default {

    data(){
        return {
            id:'',
            disciplina: new Disciplina()
        }
    },
     created() {
        this.service = new DisciplinaService(this.$resource);
        // if (this.id) {
        // this.service.busca(this.id).then(aluno => {
        //         this.aluno = aluno;
        //         this.selectedOptions.state = this.cidades.findEstado(this.aluno.state);
        //         this.selectedOptions.city = this.aluno.city;
        //         this.changeEstado();
        //     });
        // }
        
    },
    methods:{
        grava() {
            this.$validator.validateAll().then(success => {
                if (success) {
                console.log(this.disciplina);
                this.service.cadastra(this.disciplina).then(resp => {
                    this.disciplina = new Disciplina();
                    this.$router.push({ name: "listar-disciplinas" });
                });
                }
            });
        }
    }
}
</script>

<style scoped>
form {
  margin: 20px 30px;
}
label[for="state"],
label[for="city"] {
  width: 100%;
}
.botao {
  float: right;
  margin: 30px 0;
}
</style>
